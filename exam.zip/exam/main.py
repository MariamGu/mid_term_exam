from registration import *
from add_funds import *
from transfer import *

register_user(accounts)
initiate_add_funds()
initiate_transfer(accounts)
